#include"iostream"
#include"fstream"
#include"funcs.hpp"
using namespace std;
int main(){
    ifstream arq1;
    Funcs f;
    arq1.open("input.data"); 
    int i=0;
    // while(i<4){
         f.ler();
    //     i++;
    // }
    //fechar();
}